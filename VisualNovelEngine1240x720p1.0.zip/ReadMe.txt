========================================================================
    		    ViNE - Visual Novel Engine v1.0
========================================================================

Welcome to version 1.0 or the visual novel engine, this is an ongoing project and this is the first
build that I have decided to release. I am eager to hear your feedback good or bad, and I am also open to
any suggestions or requests that you might have.

There are three script files that are used to making your visual novel.

backgrounds.txt: This is where you load in all of your background assets, its as easy as entering a few simple lines
actors.txt: works the same as backgrounds.txt but for all of your actors
scenes.txt: this is the main file and the file in which you will write your scenes and screenplay

There are more detailed instructions in each script file

If you wish to leave any feedback please do by sending an email: Commandogrant21@sky.com

And feel free to contact me if you are making use of the engine and require a specific feature, i'll may either release
it as an update or make an exclusive build for yourself.

Thanks! and enjoy making visual novels

/////////////////////////////////////////////////////////////////////////////
Credits:

	Programmer/Developer: Grant Medlyn - Commandogrant21@sky.com

	Thanks to Daniel Tilbey for providing the art assets that I have 
	used in the visual novel example, his website: nanodive.com

/////////////////////////////////////////////////////////////////////////////
